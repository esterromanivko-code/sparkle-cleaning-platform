'use strict';
// server.js — Sparkle main server

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const {
  authLimiter, bgCheckLimiter, cashoutLimiter,
  messageLimiter, apiLimiter, adminLimiter,
  sanitizeInput, securityHeaders, detectSuspiciousActivity,
} = require('./middleware/security');
const authRoutes    = require('./routes/auth');
const jobRoutes     = require('./routes/jobs');
const profileRoutes = require('./routes/profiles');
const bgCheckRoutes = require('./routes/backgroundCheck');
const adminRoutes        = require('./routes/admin');
const authExtendedRoutes  = require('./routes/authExtended');
const bidRoutes           = require('./routes/bids');
const emailVerifyRoutes   = require('./routes/emailVerification');

// ═══════════════════════════════════════════════════
//  STARTUP VALIDATION — refuse to run without critical config
// ═══════════════════════════════════════════════════
const REQUIRED_ENV = ['JWT_SECRET'];
const PROD_REQUIRED = ['STRIPE_SECRET_KEY', 'FRONTEND_URL'];

const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length > 0) {
  console.error('\n❌  FATAL: Missing required environment variables:', missing.join(', '));
  console.error('   Add them to your .env file or Railway Variables.\n');
  process.exit(1);
}

if (process.env.NODE_ENV === 'production') {
  const missingProd = PROD_REQUIRED.filter(k => !process.env[k]);
  if (missingProd.length > 0) {
    console.error('\n❌  FATAL: Missing required production environment variables:', missingProd.join(', '));
    process.exit(1);
  }
  if (process.env.JWT_SECRET === 'CHANGE_ME_IN_PRODUCTION' || process.env.JWT_SECRET.length < 32) {
    console.error('\n❌  FATAL: JWT_SECRET must be a random string of at least 32 characters in production.');
    process.exit(1);
  }
}

require('./db');

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(helmet({ hsts: process.env.NODE_ENV === 'production' ? { maxAge: 31536000, includeSubDomains: true } : false }));
app.use(securityHeaders);
app.use(cors({
  origin: (origin, cb) => {
    const allowed = [process.env.FRONTEND_URL||'http://localhost:3000','http://localhost:3000','http://localhost:5173'];
    cb(null, !origin || allowed.includes(origin) || process.env.NODE_ENV !== 'production');
  },
  credentials: true,
  allowedHeaders: ['Content-Type','Authorization'],
  methods: ['GET','POST','PUT','DELETE','PATCH'],
}));
app.use('/api/background-check/webhook', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '512kb' }));
app.use(express.urlencoded({ extended: true, limit: '512kb' }));
app.use('/api', apiLimiter);
app.use(sanitizeInput);
app.use(detectSuspiciousActivity);

app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString(), version: '1.0.0' }));

app.use('/api/auth',                    authLimiter, authRoutes);
// Password reset, refresh tokens, 2FA, file uploads
app.use('/api',                         authExtendedRoutes);
app.use('/api/jobs',                    jobRoutes);
app.use('/api/background-check/initiate', bgCheckLimiter);
app.use('/api/background-check',        bgCheckRoutes);
app.use('/api/earnings/cashout',         cashoutLimiter);
app.use('/api/messages',                messageLimiter);
app.use('/api/admin',                   adminLimiter, adminRoutes);
app.use('/api/pro',                     adminRoutes);
app.use('/api/profile',                 profileRoutes);
app.use('/api/bids',                    bidRoutes);
app.use('/api/verify-email',            emailVerifyRoutes);
app.use('/api',                         profileRoutes);

app.use((req, res) => res.status(404).json({ error: `Route ${req.method} ${req.path} not found` }));
app.use((err, req, res, next) => {
  logger.error('[ERROR]', { method: req.method, path: req.path, error: err.message, stack: err.stack });
  if (err.message && err.message.startsWith('CORS:')) return res.status(403).json({ error: 'CORS blocked' });
  res.status(err.status||500).json({
    error: err.status ? err.message : 'Internal server error',
    ...(process.env.NODE_ENV==='development' && { debug: err.message }),
  });
});

app.listen(PORT, () => console.log(`
  ✅  Sparkle backend running on port ${PORT}
  📋  Fees: Client 8% / Business 10% / BG Check $40 / Instant cashout $10
`));

module.exports = app;
